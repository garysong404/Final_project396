package domain.game;

import java.util.Random;

public class PlayerManager {
    private Player[] players;
    private int numberOfPlayers;
    private final Instantiator instantiator;
    private final Random rand;

    private static final String INVALID_PLAYER_INDEX_EXCEPTION = "Invalid player index.";
    private static final String NO_PLAYERS_EXCEPTION = "No players to select from.";


    public PlayerManager(int numberOfPlayers, Instantiator instantiator, Random rand) {
        this.numberOfPlayers = numberOfPlayers;
        this.instantiator = instantiator;
        this.rand = rand;
        this.players = new Player[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) {
            this.players[i] = instantiator.createPlayer(i);
        }
    }

    public Player getPlayerAtIndex(int playerIndex) {
        if (checkUserOutOfBounds(playerIndex)) {
            throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
        }
        return players[playerIndex];
    }

    public int getNumberOfPlayers() {
        return numberOfPlayers;
    }

    public int checkNumberOfAlivePlayers() {
        int alivePlayers = 0;
        for (int i = 0; i < numberOfPlayers; i++) {
            if (checkIfPlayerIsAlive(i)) {
                alivePlayers++;
            }
        }
        return alivePlayers;
    }

    public boolean checkIfPlayerIsAlive(int playerIndex) {
        if (checkUserOutOfBounds(playerIndex)) {
            throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
        }
        return !players[playerIndex].getIsDead();
    }

    public Player selectRandomPlayer() {
        if (numberOfPlayers == 0) {
            throw new UnsupportedOperationException(NO_PLAYERS_EXCEPTION);
        }
        int randomPlayerIndex = rand.nextInt(numberOfPlayers);
        return players[randomPlayerIndex];
    }

    public void setPlayerCursed(int playerIndex, boolean isCursed) {
        if (checkUserOutOfBounds(playerIndex)) {
            throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
        }
        players[playerIndex].setCursed(isCursed);
    }

    public void setNumberOfPlayers(int numPlayers) {
        this.numberOfPlayers = numPlayers;
        this.players = new Player[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) {
            this.players[i] = instantiator.createPlayer(i);
        }
    }

    public void reversePlayers() {
        int startPointer = 0;
        int endPointer = numberOfPlayers - 1;
        while (startPointer < endPointer) {
            Player temporaryPlayerOne = players[startPointer];
            Player temporaryPlayerTwo = players[endPointer];
            players[startPointer] = temporaryPlayerTwo;
            players[endPointer] = temporaryPlayerOne;
            startPointer++;
            endPointer--;
        }
    }

    private boolean checkUserOutOfBounds(int userIndex) {
        return userIndex < 0 || userIndex >= numberOfPlayers;
    }
} 