package domain.game;

public enum GameType {
	NONE,
	EXPLODING_KITTENS,
	STREAKING_KITTENS,
	IMPLODING_KITTENS
}
