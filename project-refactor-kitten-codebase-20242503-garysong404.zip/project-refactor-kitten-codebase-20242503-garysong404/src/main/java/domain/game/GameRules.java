package domain.game;

public class GameRules {

    public static boolean checkUserWithinBounds(int userIndex, int numberOfPlayers) {
        return userIndex >= 0 && userIndex < numberOfPlayers;
    }

    public static boolean checkInvalidNumberOfPlayers(int numPlayers) {
        final int minPlayerThreshold = 2;
        final int maxPlayerThreshold = 4;
        return numPlayers < minPlayerThreshold || numPlayers > maxPlayerThreshold;
    }

    public static boolean hasZeroPlayers(int numberOfPlayers) {
        return numberOfPlayers == 0;
    }

    public static boolean checkIfNumberOfTurnsIsZero(TurnManager turnManager) {
        return turnManager.getNumberOfTurns() == 0;
    }

    public static boolean checkCardOutOfBoundsIndexed(int cardIndex, Player player) {
        return cardIndex < 0 || cardIndex >= player.getHandSize();
    }

    public static boolean checkDeckHasOneCardOrLess(Deck deck) {
        return deck.getDeckSize() <= 1;
    }

    public static boolean checkPlayerHandEmpty(Player player) {
        return player.getHandSize() == 0;
    }

    public static boolean checkIfNumberOfTurnsOutOfBounds(TurnManager turnManager) {
        final int maxTurns = 6;
        final int minTurns = 1;
        return turnManager.getNumberOfTurns() > maxTurns || turnManager.getNumberOfTurns() < minTurns;
    }

    public static boolean matchingGameType(GameType gameType) {
        return gameType == null;
    }
} 