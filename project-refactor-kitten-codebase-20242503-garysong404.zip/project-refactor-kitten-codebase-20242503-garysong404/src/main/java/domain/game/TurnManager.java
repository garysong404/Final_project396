package domain.game;

import java.util.List;

public class TurnManager {

    private int currentPlayerTurn;
    private int currentPlayerNumberOfTurns;
    private boolean isReversed;
    private List<Integer> attackQueue;
    private int attackCounter;
    private int numberOfAttacks;
    private int[] turnTracker;
    private boolean attacked;
    private int numberOfPlayers;
    private PlayerManager playerManager;

    public TurnManager(List<Integer> attackQueue, PlayerManager playerManager) {
        this.playerManager = playerManager;
        this.attackQueue = attackQueue;
        this.numberOfPlayers = 0;
        this.turnTracker = new int[0];
        this.currentPlayerTurn = 0;
        this.currentPlayerNumberOfTurns = 1; // Default to 1 turn
        this.isReversed = false;
        this.attackCounter = 0;
        this.numberOfAttacks = 0;
        this.attacked = false;
    }

    public void setNumberOfPlayers(int numberOfPlayers) {
        this.numberOfPlayers = numberOfPlayers;
        this.turnTracker = new int[numberOfPlayers];
        for (int i = 0; i < numberOfPlayers; i++) {
            this.turnTracker[i] = 1;
        }
    }

    public void playReverse() {
        int startPointer = 0;
        int endPointer = numberOfPlayers - 1;
        isReversed = !isReversed;
        
        playerManager.reversePlayers();

        currentPlayerTurn = numberOfPlayers - currentPlayerTurn - 1;
        decrementNumberOfTurns();
        if (checkIfNumberOfTurnsIsZero()) {
            incrementPlayerTurn();
        }
    }

    public void incrementPlayerTurn() {
        if (numberOfPlayers == 0) {
            return;
        }
        do {
            currentPlayerTurn = (currentPlayerTurn + 1) % numberOfPlayers;
        } while (!playerManager.checkIfPlayerIsAlive(currentPlayerTurn));
    }

    public void incrementAttackCounter() {
        if (numberOfPlayers == 0) {
            return;
        }
        do {
            attackCounter = (attackCounter + 1) % numberOfPlayers;
        } while (!playerManager.checkIfPlayerIsAlive(attackCounter));
    }

    public void setAttackCounter(int playerIndex) {
        attackCounter = playerIndex;
    }

    public void addAttacks() {
        numberOfAttacks += 2;
    }

    public void addAttackQueue(int attack) {
        attackQueue.add(attack);
    }

    public int removeAttackQueue() {
        return attackQueue.remove(0);
    }

    public boolean isAttackQueueEmpty() {
        return attackQueue.isEmpty();
    }

    public void setPlayerNumberOfTurns() {
        this.currentPlayerNumberOfTurns = turnTracker[currentPlayerTurn];
    }

    public int getPlayerTurn() {
        return currentPlayerTurn;
    }

    public void setCurrentPlayerNumberOfTurns(int numberOfTurns) {
        this.currentPlayerNumberOfTurns = numberOfTurns;
    }

    public void decrementNumberOfTurns() {
        currentPlayerNumberOfTurns--;
    }

    public int getNumberOfTurns() {
        return currentPlayerNumberOfTurns;
    }

    private boolean checkIfNumberOfTurnsIsZero() {
        return currentPlayerNumberOfTurns == 0;
    }

    public void setTurnToTargetedIndexIfAttackOccurred() {
        if (attacked) {
            if (isReversed) {
                currentPlayerTurn = (attackCounter + 1) % numberOfPlayers;
            } else {
                currentPlayerTurn = (attackCounter - 1 + numberOfPlayers) % numberOfPlayers;
            }
        }
    }

    public int getTurnCountOfPlayer(int playerIndex) {
        return turnTracker[playerIndex];
    }

    public boolean getAttacked() {
        return attacked;
    }

    public int getAttackCounter() {
        return attackCounter;
    }

    public int getNumberOfAttacks() {
        return numberOfAttacks;
    }

    public void setNumberOfAttacks(int numberOfAttacks) {
        this.numberOfAttacks = numberOfAttacks;
    }

    public void setAttacked(boolean attacked) {
        this.attacked = attacked;
    }

    public boolean getIsReversed() {
        return isReversed;
    }

    public void startAttackPhase() {

        final int attackedAttackThreshold = 4;
        attackCounter = currentPlayerTurn;
        numberOfAttacks = 0;
        while (!isAttackQueueEmpty()) {
            int attack = removeAttackQueue();
            if (attack <= attackedAttackThreshold) {
                playTargetedAttack(attack);
            } else {
                playAttack();
            }
        }
        if (turnTracker[attackCounter] == 1) {
            turnTracker[attackCounter] = 0;
        }
        if (attackCounter == currentPlayerTurn) {
            currentPlayerNumberOfTurns += numberOfAttacks;
            turnTracker[attackCounter] = 1;
            attacked = false;
        } else {
            turnTracker[attackCounter] += numberOfAttacks;
        }
        decrementNumberOfTurns();
        if (checkIfNumberOfTurnsIsZero()) {
            incrementPlayerTurn();
        }
    }

    public void playAttack() {
        incrementAttackCounter();
        addAttacks();
        attacked = true;
    }

    public void playTargetedAttack (int attackedPlayerIndex) {
        setAttackCounter(attackedPlayerIndex);
        addAttacks();
        attacked = true;
    }
} 