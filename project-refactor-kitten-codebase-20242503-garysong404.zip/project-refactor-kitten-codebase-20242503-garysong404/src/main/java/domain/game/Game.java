package domain.game;

import java.util.List;
import java.util.Random;
import java.util.ArrayList;

public class Game {
	private GameType gameType;
	private Deck deck;
	private PlayerManager playerManager;
	private Random rand;
	private TurnManager turnManager;
	private Instantiator instantiator;

	private static final String PLAYER_HAND_EMPTY_EXCEPTION = "Player has no cards to steal";
	private static final String INVALID_PLAYER_INDEX_EXCEPTION = "Invalid player index.";
	private static final String INVALID_GAME_TYPE_EXCEPTION = "Must Provide a Valid Game Type";
	private static final String NO_PLAYERS_EXCEPTION = "No players to select from.";
	private static final String OUT_OF_BOUNDS_PLAYER_INDEX_EXCEPTION =
			"playerIndex out of Bounds";
	private static final String PLAYER_DEAD_EXCEPTION = "Player is dead";
	private static final String CARD_INDEX_OUT_OF_BOUNDS_EXCEPTION = "cardIndex out of Bounds";
	private static final String CARD_TYPE_NOT_FOUND_EXCEPTION =
			"Player does not have the card type to steal";
	private static final String INVALID_NUMBER_OF_PLAYERS_EXCEPTION =
			"Number of players must be between 2 and 5 inclusive";
	private static final String NUMBER_OF_TURNS_OUT_OF_BOUNDS_EXCEPTION =
			"Number of turns must be between 1 and 6.";

	public Game (int numberOfPlayers, GameType gameType,
                 Deck deck,
                 Instantiator instantiator, Random rand) {
		this.gameType = gameType;
		this.deck = deck;
		this.rand = rand;
		this.instantiator = instantiator;
		this.playerManager = new PlayerManager(numberOfPlayers, instantiator, rand);
		this.turnManager = new TurnManager(new ArrayList<>(), playerManager);
		this.turnManager.setNumberOfPlayers(numberOfPlayers);
	}

	public void swapTopAndBottom() {
		if (GameRules.checkDeckHasOneCardOrLess(deck)) {
			return;
		}
		Card bottomCard = deck.drawCardFromBottom();
		Card topCard = drawCard();
		deck.insertCard(bottomCard.getCardType(), 1, false);
		deck.insertCard(topCard.getCardType(), 1, true);
	}

	public Card stealRandomCard(int playerToStealFrom) {
		Player player = playerManager.getPlayerAtIndex(playerToStealFrom);
		if (GameRules.checkPlayerHandEmpty(player)) {
			throw new IllegalArgumentException(PLAYER_HAND_EMPTY_EXCEPTION);
		}

		int randomCardIndex = rand.nextInt(player.getHandSize());
		Card stealedCard = player.getCardAt(randomCardIndex);
		player.removeCardFromHand(randomCardIndex);
		addCardToHand(stealedCard);
		return stealedCard;
	}

	public void stealTypeCard(CardType cardType, int playerToStealFrom) {
		Player player = playerManager.getPlayerAtIndex(playerToStealFrom);
		try {
			int cardIndex = getIndexOfCardFromHand(playerToStealFrom,
					cardType);
			Card stealedCard = player.getCardAt(cardIndex);
			player.removeCardFromHand(cardIndex);
			playerManager.getPlayerAtIndex(turnManager.getPlayerTurn()).addCardToHand(stealedCard);
		}
		catch (IllegalArgumentException e) {
			throw new IllegalArgumentException
					(CARD_TYPE_NOT_FOUND_EXCEPTION);
		}
	}


	public void startAttackPhase() {
		turnManager.startAttackPhase();
	}

	public void playAttack() {
		turnManager.playAttack();
	}

	public void playTargetedAttack (int attackedPlayerIndex) {
		turnManager.playTargetedAttack(attackedPlayerIndex);
	}

	public boolean playExplodingKitten(int playerIndex) {
		if (!checkUserWithinBounds(playerIndex)) {
			throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
		}
		if (checkIfPlayerHasCard(playerIndex, CardType.DEFUSE)) {
			return false;
		}
		playerManager.getPlayerAtIndex(playerIndex).setIsDead();
		if (playerIndex == turnManager.getPlayerTurn()) {
			turnManager.setCurrentPlayerNumberOfTurns(0);
		}
		return true;
	}

	public void playImplodingKitten() {
		turnManager.setCurrentPlayerNumberOfTurns(0);
		playerManager.getPlayerAtIndex(turnManager.getPlayerTurn()).setIsDead();
	}

	public void playDefuse(int idxToInsertExplodingKitten, int playerIndex) {
		if (!checkUserWithinBounds(playerIndex)) {
			throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
		}
		Player currentPlayer = playerManager.getPlayerAtIndex(playerIndex);
		try {
			deck.insertExplodingKittenAtIndex(idxToInsertExplodingKitten);
		} catch (UnsupportedOperationException e) {
			throw e;
		}
		int defuseIdx = currentPlayer.getIndexOfCard(CardType.DEFUSE);
		currentPlayer.removeCardFromHand(defuseIdx);

		if (playerIndex == turnManager.getPlayerTurn()) {
			turnManager.setCurrentPlayerNumberOfTurns(0);
		}

	}

	public Card drawFromBottom() {
		return deck.drawCardFromBottom();
	}

	public void playCatomicBomb() {
		int numberOfBombs = deck.removeBombs();
		deck.insertCard(CardType.EXPLODING_KITTEN, numberOfBombs, false);
		turnManager.decrementNumberOfTurns();
		if (GameRules.checkIfNumberOfTurnsIsZero(turnManager)) {
			turnManager.incrementPlayerTurn();
		}
	}

	public void setNumberOfPlayers (int numberOfPlayers) {
		if (GameRules.checkInvalidNumberOfPlayers(numberOfPlayers)) {
			throw new IllegalArgumentException
					(INVALID_NUMBER_OF_PLAYERS_EXCEPTION);
		}
		playerManager.setNumberOfPlayers(numberOfPlayers);
		turnManager.setNumberOfPlayers(numberOfPlayers);
		deck.setNumberOfPlayers(numberOfPlayers);
	}

	public void playReverse() {
		turnManager.playReverse();
	}

	public void retrieveGameMode(GameType gameType) {
		if (GameRules.matchingGameType(gameType)) {
			throw new IllegalArgumentException(INVALID_GAME_TYPE_EXCEPTION);
		}
		this.gameType = gameType;
		deck.chooseGameType(gameType);
	}

	public Player selectRandomPlayer() {
		if (GameRules.hasZeroPlayers(playerManager.getNumberOfPlayers())) {
			throw new UnsupportedOperationException(NO_PLAYERS_EXCEPTION);
		}
		return playerManager.selectRandomPlayer();
	}

	public void playShuffle(int numberOfShuffles) {
		for (int i = 0; i < numberOfShuffles; i++) {
			deck.shuffleDeck();
		}
	}


	public int playSkip(boolean superSkip) {
		if (GameRules.checkIfNumberOfTurnsOutOfBounds(turnManager)) {
			throw new UnsupportedOperationException(
					NUMBER_OF_TURNS_OUT_OF_BOUNDS_EXCEPTION);
		}
		if (superSkip) {
			turnManager.setCurrentPlayerNumberOfTurns(0);
		} else {
			turnManager.decrementNumberOfTurns();
		}

		if (GameRules.checkIfNumberOfTurnsIsZero(turnManager)) {
			turnManager.incrementPlayerTurn();
		}
		return turnManager.getPlayerTurn();
	}

	public void playGarbageCollection(CardType cardToDiscard) {
		removeCardFromHand(turnManager.getPlayerTurn(), cardToDiscard);
		turnManager.decrementNumberOfTurns();
		if (GameRules.checkIfNumberOfTurnsIsZero(turnManager)) {
			turnManager.incrementPlayerTurn();
		}
	}

	public void playNope(int playerIndex) {
		//For now, this is empty. It will be updated in future sprints.
	}

	public void setPlayerCursed(int playerIndex, boolean isCursed) {
		playerManager.setPlayerCursed(playerIndex, isCursed);
	}

	public Deck getDeck() {
		return deck;
	}

	public void incrementPlayerTurn() {
		turnManager.incrementPlayerTurn();
	}

	public GameType getGameTypeForTesting() {
		return gameType;
	}

	public GameType getGameType() {
		return gameType;
	}

	public Player getPlayerAtIndex(int playerIndex) {
		return playerManager.getPlayerAtIndex(playerIndex);
	}

	public void addAttacks() {
		turnManager.addAttacks();
	}

	public void playMark(int playerIndex, int cardIndex) {
		if (!checkUserWithinBounds(playerIndex)) {
			throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
		}
		if (checkIfPlayerDead(playerIndex)) {
			throw new UnsupportedOperationException(PLAYER_DEAD_EXCEPTION);
		}
		if (checkCardOutOfBoundsIndexed(cardIndex, playerIndex)) {
			throw new UnsupportedOperationException(CARD_INDEX_OUT_OF_BOUNDS_EXCEPTION);
		}
		playerManager.getPlayerAtIndex(playerIndex).getCardAt(cardIndex).markCard();
		turnManager.decrementNumberOfTurns();
		if (GameRules.checkIfNumberOfTurnsIsZero(turnManager)) {
			turnManager.incrementPlayerTurn();
		}
	}

	public void addAttackQueue(int attack) {
		turnManager.addAttackQueue(attack);
	}

	public int removeAttackQueue() {
		return turnManager.removeAttackQueue();
	}

	public boolean isAttackQueueEmpty() {
		return turnManager.isAttackQueueEmpty();
	}


	public void setPlayerNumberOfTurns() {
		turnManager.setPlayerNumberOfTurns();
	}

	public int getPlayerTurn() {
		return turnManager.getPlayerTurn();
	}

	public int getNumberOfPlayers() {
		return playerManager.getNumberOfPlayers();
	}

	public int checkNumberOfAlivePlayers() {
		return playerManager.checkNumberOfAlivePlayers();
	}

	public void setCurrentPlayerNumberOfTurns(int numberOfTurns) {
		turnManager.setCurrentPlayerNumberOfTurns(numberOfTurns);
	}

	public void decrementNumberOfTurns() {
		turnManager.decrementNumberOfTurns();
	}

	public int getNumberOfTurns() {
		return turnManager.getNumberOfTurns();
	}

	public int getDeckSize() {
		return deck.getDeckSize();
	}

	public Card drawCard() {
		return deck.drawCard();
	}

	public Card getCardAtIndex(int cardIndex) {
		return deck.getCardAtIndex(cardIndex);
	}

	public void removeCardFromHand(int playerIndex, CardType cardType) {
		int cardIndex = getIndexOfCardFromHand(playerIndex, cardType);
		playerManager.getPlayerAtIndex(playerIndex).removeCardFromHand(cardIndex);
	}

	public int getIndexOfCardFromHand(int playerIndex, CardType cardType) {
		return playerManager.getPlayerAtIndex(playerIndex).getIndexOfCard(cardType);
	}

	public void addCardToHand(Card card) {
		playerManager.getPlayerAtIndex(turnManager.getPlayerTurn()).addCardToHand(card);
	}

	public boolean checkIfPlayerDead(int playerIndex) {
		return !playerManager.checkIfPlayerIsAlive(playerIndex);
	}

	public boolean checkIfPlayerHasCard(int playerIndex, CardType cardType) {
		return playerManager.getPlayerAtIndex(playerIndex).hasCard(cardType);
	}

	public int countCards(int playerIndex, CardType cardType) {
		return playerManager.getPlayerAtIndex(playerIndex).checkNumberOfCardsInHand(cardType);
	}

	public CardType getCardType(int playerIndex, int cardIndex) {
		if (checkCardOutOfBoundsIndexed(cardIndex, playerIndex)) {
			throw new UnsupportedOperationException(CARD_INDEX_OUT_OF_BOUNDS_EXCEPTION);
		}
		return playerManager.getPlayerAtIndex(playerIndex).getCardAt(cardIndex).getCardType();
	}

	public int getHandSize(int playerIndex) {
		if (!checkUserWithinBounds(playerIndex)) {
			throw new UnsupportedOperationException(INVALID_PLAYER_INDEX_EXCEPTION);
		}
		return playerManager.getPlayerAtIndex(playerIndex).getHandSize();
	}

	public CardType getDeckCardType(int deckIndex) {
		return deck.getCardAtIndex(deckIndex).getCardType();
	}

	public boolean getIsReversed() {
		return turnManager.getIsReversed();
	}

	protected void setCurrentPlayerTurn(int turn) {
		// This method is for testing purposes only.
	}

	public boolean checkCardOutOfBoundsIndexed(int cardIndex, int playerIndex) {
		return GameRules.checkCardOutOfBoundsIndexed(cardIndex, playerManager.getPlayerAtIndex(playerIndex));
	}

	public boolean checkUserWithinBounds(int userIndex) {
		return GameRules.checkUserWithinBounds(userIndex, playerManager.getNumberOfPlayers());
	}

	public void setTurnToTargetedIndexIfAttackOccurred() {
		turnManager.setTurnToTargetedIndexIfAttackOccurred();
	}

	public int getTurnCountOfPlayer(int playerIndex) {
		return turnManager.getTurnCountOfPlayer(playerIndex);
	}

	public boolean getAttacked() {
		return turnManager.getAttacked();
	}

	public int getAttackCounter() {
		return turnManager.getAttackCounter();
	}

	public int getNumberOfAttacks() {
		return turnManager.getNumberOfAttacks();
	}

	public boolean checkIfPlayerIsAlive(int playerIndex) {
		return playerManager.checkIfPlayerIsAlive(playerIndex);
	}

}