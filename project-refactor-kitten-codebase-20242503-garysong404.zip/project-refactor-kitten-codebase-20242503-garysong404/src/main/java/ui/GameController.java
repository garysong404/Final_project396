package ui;

import domain.game.Game;
import domain.game.Player;
import domain.game.GameType;
import domain.game.Card;
import domain.game.CardType;
import ui.actions.Action;

import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

public class GameController {

    private final Game game;
    private final GameUI gameUI;

    public GameController(Game game, GameUI gameUI) {
        this.game = game;
        this.gameUI = gameUI;
        this.gameUI.setController(this);
    }

    public void playAction(Action action) {
        if (!gameUI.promptForNope()) {
            action.execute();
        }
    }

    private void setupGame() {
        GameSetupUI setupUI = new GameSetupUI(game);
        ResourceBundle messages = setupUI.chooseLanguage();
        gameUI.setMessages(messages);
        setupUI.chooseGame();
        setupUI.chooseNumberOfPlayers();

        for (int i = 0; i < game.getNumberOfPlayers(); i++) {
            game.getPlayerAtIndex(i).addDefuse(new Card(CardType.DEFUSE));
        }

        game.getDeck().initializeDeck();
        game.getDeck().shuffleDeck();

        final int initialHandSize = 5;
        for (int i = 0; i < initialHandSize; i++) {
            for (int j = 0; j < game.getNumberOfPlayers(); j++) {
                Player currentPlayer = game.getPlayerAtIndex(j);
                currentPlayer.addCardToHand(game.getDeck().drawCard());
            }
        }

        if (game.getGameType() == GameType.STREAKING_KITTENS) {
            game.getDeck().insertCard(CardType.EXPLODING_KITTEN, game.getNumberOfPlayers(), false);
        } else {
            game.getDeck().insertCard(CardType.EXPLODING_KITTEN, game.getNumberOfPlayers() - 1, false);
        }

        if (game.getGameType() == GameType.IMPLODING_KITTENS) {
            game.getDeck().insertCard(CardType.IMPLODING_KITTEN, 1, false);
        }

        game.playShuffle(1);
    }

    public void run() {
        setupGame();

        while (!gameUI.checkIfGameOver()) {
            gameUI.startTurn();
        }

        gameUI.endGame();
    }
} 