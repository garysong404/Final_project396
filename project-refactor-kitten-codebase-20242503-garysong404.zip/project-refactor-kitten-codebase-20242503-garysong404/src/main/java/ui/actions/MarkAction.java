package ui.actions;

import domain.game.Game;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class MarkAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public MarkAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String decidedMark = messages.getString("decidedMark");
        final String enterPlayerToMark = messages.getString("enterPlayerToMark");
        final String invalidPlayerRange = messages.getString("invalidPlayerRange");
        final String playerIsDead = messages.getString("playerIsDead");
        final String enterCardToMark = messages.getString("enterCardToMark");
        final String invalidCardRange = messages.getString("invalidCardRange");
        final String cardIsMarked = messages.getString("cardIsMarked");
        final String enterInteger = messages.getString("enterInteger");

        System.out.println(decidedMark);

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        int playerToMark;
        while (true) {
            System.out.print(enterPlayerToMark);
            try {
                playerToMark = scanner.nextInt();
                if (game.checkUserWithinBounds(playerToMark)) {
                    if (game.checkIfPlayerIsAlive(playerToMark)) {
                        break;
                    } else {
                        System.out.println(playerIsDead);
                    }
                } else {
                    System.out.println(invalidPlayerRange);
                }
            } catch (Exception e) {
                System.out.println(enterInteger);
                scanner.next();
            }
        }

        int cardToMark;
        while (true) {
            System.out.print(enterCardToMark);
            try {
                cardToMark = scanner.nextInt();
                if (cardToMark >= 0 && cardToMark < game.getHandSize(playerToMark)) {
                    break;
                } else {
                    System.out.println(invalidCardRange);
                }
            } catch (Exception e) {
                System.out.println(enterInteger);
                scanner.next();
            }
        }

        game.playMark(playerToMark, cardToMark);
        System.out.println(MessageFormat.format(cardIsMarked, cardToMark, playerToMark));
    }
} 