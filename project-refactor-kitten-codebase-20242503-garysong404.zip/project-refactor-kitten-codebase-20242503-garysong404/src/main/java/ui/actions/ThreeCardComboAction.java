package ui.actions;

import domain.game.CardType;
import domain.game.Game;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class ThreeCardComboAction implements Action {

    private final Game game;
    private final ResourceBundle messages;
    private final CardType cardType;

    public ThreeCardComboAction(Game game, ResourceBundle messages, CardType cardType) {
        this.game = game;
        this.messages = messages;
        this.cardType = cardType;
    }

    @Override
    public void execute() {
        final String decidedThreeCards = messages.getString("decidedThreeCards");
        final String enterPlayerToSteal = messages.getString("enterPlayerToSteal");
        final String invalidPlayerIndex = messages.getString("invalidPlayerIndex");
        final String playerIsDead = messages.getString("playerIsDead");
        final String cannotStealFromSelf = messages.getString("cannotStealFromSelf");
        final String enterValidInteger = messages.getString("enterValidInteger");
        final String enterCardToSteal = messages.getString("enterCardToSteal");
        final String invalidCard = messages.getString("invalidCard");
        final String playerStoleCard = messages.getString("playerStoleCard");
        final String playerDidNotHaveCard = messages.getString("playerDidNotHaveCard");

        System.out.println(decidedThreeCards);
        game.removeCardFromHand(game.getPlayerTurn(), cardType);
        game.removeCardFromHand(game.getPlayerTurn(), cardType);

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        int playerToStealFrom;
        while (true) {
            System.out.print(enterPlayerToSteal);
            try {
                playerToStealFrom = scanner.nextInt();
                scanner.nextLine(); 
                if (game.checkUserWithinBounds(playerToStealFrom)) {
                    if (game.checkIfPlayerIsAlive(playerToStealFrom)) {
                        if (playerToStealFrom != game.getPlayerTurn()) {
                            break;
                        } else {
                            System.out.println(cannotStealFromSelf);
                        }
                    } else {
                        System.out.println(playerIsDead);
                    }
                } else {
                    System.out.println(invalidPlayerIndex);
                }
            } catch (Exception e) {
                System.out.println(enterValidInteger);
                scanner.next();
            }
        }

        CardType cardToSteal;
        while (true) {
            System.out.println(enterCardToSteal);
            String cardName = scanner.nextLine().toUpperCase().replace(" ", "_");
            try {
                cardToSteal = CardType.valueOf(cardName);
                break;
            } catch (IllegalArgumentException e) {
                System.out.println(invalidCard);
            }
        }

        try {
            game.stealTypeCard(cardToSteal, playerToStealFrom);
            System.out.println(MessageFormat.format(playerStoleCard, playerToStealFrom, cardToSteal));
        } catch (IllegalArgumentException e) {
            System.out.println(MessageFormat.format(playerDidNotHaveCard, playerToStealFrom, cardToSteal));
        }
    }
} 