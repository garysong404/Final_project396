package ui.actions;

import domain.game.CardType;
import domain.game.Game;
import domain.game.Player;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class SpecialComboAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public SpecialComboAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String enterCombo = messages.getString("enterCombo");
        final String invalidCombo = messages.getString("invalidCombo");

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        System.out.println(enterCombo);
        String combo = scanner.nextLine();
        switch (combo) {
            case "2":
                playTwoCardCombo();
                break;
            case "3":
                playThreeCardCombo();
                break;
            default:
                System.out.println(invalidCombo);
        }
    }

    private void playTwoCardCombo() {
        CardType twoCardType = getCatCardType(2);
        if (twoCardType != null) {
            new TwoCardComboAction(game, messages, twoCardType).execute();
        }
    }

    private void playThreeCardCombo() {
        CardType threeCardType = getCatCardType(3);
        if (threeCardType != null) {
            new ThreeCardComboAction(game, messages, threeCardType).execute();
        }
    }

    private CardType getCatCardType(int comboSize) {
        Player player = game.getPlayerAtIndex(game.getPlayerTurn());
        if (player.checkNumberOfCardsInHand(CardType.CAT_ONE) >= comboSize) {
            return CardType.CAT_ONE;
        }
        if (player.checkNumberOfCardsInHand(CardType.CAT_TWO) >= comboSize) {
            return CardType.CAT_TWO;
        }
        if (player.checkNumberOfCardsInHand(CardType.CAT_THREE) >= comboSize) {
            return CardType.CAT_THREE;
        }
        if (player.checkNumberOfCardsInHand(CardType.CAT_FOUR) >= comboSize) {
            return CardType.CAT_FOUR;
        }
        System.out.println(messages.getString("notEnoughCardsComboMessage"));
        return null;
    }
} 