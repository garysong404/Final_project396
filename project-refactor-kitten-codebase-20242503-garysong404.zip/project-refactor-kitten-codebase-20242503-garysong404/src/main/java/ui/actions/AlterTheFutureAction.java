package ui.actions;

import domain.game.Card;
import domain.game.CardType;
import domain.game.Game;
import domain.game.GameType;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

public class AlterTheFutureAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public AlterTheFutureAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String alterFutureMessage = messages.getString("alterFutureMessage");
        final String futureCardsMessage = messages.getString("futureCardsMessage");
        final String enterNewOrderMessage = messages.getString("enterNewOrderMessage");
        final String positionPrompt = messages.getString("positionPrompt");
        final String positionTakenMessage = messages.getString("positionTakenMessage");
        final String invalidPositionMessage = messages.getString("invalidPositionMessage");
        final String futureAlteredMessage = messages.getString("futureAlteredMessage");
        final String cardDisplayFormat = messages.getString("cardDisplayFormat");

        System.out.println(alterFutureMessage);

        final int cardsAlteredStreaking = 5;
        final int cardsAlteredExploding = 3;
        int deckSize = game.getDeck().getDeckSize();
        int cardsToReveal = (game.getGameType() == GameType.STREAKING_KITTENS)
                ? cardsAlteredStreaking : cardsAlteredExploding;
        cardsToReveal = Math.min(cardsToReveal, deckSize);

        final String futureMessage =
                MessageFormat.format(futureCardsMessage, cardsToReveal);
        System.out.println(futureMessage);

        List<Card> revealedCards = new ArrayList<>();
        for (int i = 0; i < cardsToReveal; i++) {
            Card card = game.getDeck().getCardAtIndex(deckSize - 1 - i);
            revealedCards.add(card);
            final String cardDisplay = MessageFormat.format
                    (cardDisplayFormat, i + 1,
                            getLocalizedCardType(card.getCardType()));
            System.out.println(cardDisplay);
        }

        final String orderPrompt =
                MessageFormat.format(enterNewOrderMessage, cardsToReveal);
        System.out.println(orderPrompt);

        int[] newOrder = new int[cardsToReveal];
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);

        for (int i = 0; i < cardsToReveal; i++) {
            final String positionRequest = MessageFormat.format(positionPrompt, i + 1);
            System.out.print(positionRequest);
            int inputPosition = scanner.nextInt();

            if (Arrays.stream(newOrder).anyMatch(pos ->
                    (deckSize - pos) == inputPosition)) {
                final String positionTaken = MessageFormat.format
                        (positionTakenMessage, inputPosition);
                System.out.println(positionTaken);
                i--;
                continue;
            }

            if (inputPosition < 1 || inputPosition > cardsToReveal) {
                final String invalidPosition = MessageFormat.format
                        (invalidPositionMessage, cardsToReveal);
                System.out.println(invalidPosition);
                i--;
                continue;
            }
            newOrder[i] = deckSize - inputPosition;
        }

        game.getDeck().reorderDeckCards(newOrder, revealedCards);
        System.out.println(futureAlteredMessage);
    }

    private String getLocalizedCardType(CardType cardType) {
        return messages.getString(cardType.name());
    }
} 