package ui.actions;

import domain.game.CardType;
import domain.game.Game;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class AttackAction implements Action {

    private final Game game;
    private final ResourceBundle messages;
    private final boolean targeted;

    public AttackAction(Game game, ResourceBundle messages, boolean targeted) {
        this.game = game;
        this.messages = messages;
        this.targeted = targeted;
    }

    @Override
    public void execute() {
        startAttackFollowUp(targeted);
        game.startAttackPhase();
    }

    private void startAttackFollowUp(boolean targeted) {
        final int normalAttack = 5;
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        int tempTurn;
        tempTurn = game.getPlayerTurn();
        tempTurn = (tempTurn + 1) % game.getNumberOfPlayers();
        if (targeted) {
            tempTurn = checkValidPlayerIndexInput();
            game.addAttackQueue(tempTurn);
        } else {
            game.addAttackQueue(normalAttack);
        }
        while (game.checkIfPlayerHasCard(tempTurn, CardType.ATTACK)
                || game.checkIfPlayerHasCard(tempTurn, CardType.TARGETED_ATTACK)) {

            if (game.checkIfPlayerHasCard(tempTurn, CardType.ATTACK)) {
                final String attackCardPrompt = MessageFormat.format(
                        messages.getString("attackCardPrompt"), tempTurn);
                final String yesOption = messages.getString("optionYes");
                final String noOption = messages.getString("optionNo");
                final String invalidChoiceMessage =
                        messages.getString("invalidChoice");
                final String playedAnotherAttack =
                        messages.getString("playedAnotherAttack");
                final String noAnotherAttack =
                        messages.getString("noAnotherAttack");

                System.out.println(attackCardPrompt);
                System.out.println(yesOption);
                System.out.println(noOption);

                String userInput = scanner.nextLine().trim();
                switch (userInput) {
                    case "1":
                        game.removeCardFromHand(tempTurn, CardType.ATTACK);
                        game.addAttackQueue(normalAttack);
                        tempTurn =
                                (tempTurn + 1) % game.getNumberOfPlayers();
                        System.out.println(playedAnotherAttack);
                        break;
                    case "2":
                        System.out.println(noAnotherAttack);
                        return;
                    default:
                        System.out.println(invalidChoiceMessage);
                        break;
                }
            } else if (game.checkIfPlayerHasCard(tempTurn, CardType.TARGETED_ATTACK)) {
                final String hasTargetedAttackPrompt = MessageFormat.format(
                        messages.getString
                                ("hasTargetedAttackPrompt"), tempTurn);
                final String yesOption = messages.getString("optionYes");
                final String noOption = messages.getString("optionNo");
                final String invalidChoiceMessage =
                        messages.getString("invalidChoice");
                final String playedAnotherTargetedAttack =
                        messages.getString("playedAnotherTargetedAttack");
                final String noAnotherTargetedAttack =
                        messages.getString("noAnotherTargetedAttack");

                System.out.println(hasTargetedAttackPrompt);
                System.out.println(yesOption);
                System.out.println(noOption);

                String userInput = scanner.nextLine().trim();
                switch (userInput) {
                    case "1":
                        game.removeCardFromHand(tempTurn,
                                CardType.TARGETED_ATTACK);
                        int playerIndex = checkValidPlayerIndexInput();
                        game.addAttackQueue(playerIndex);
                        tempTurn = playerIndex;
                        System.out.println(playedAnotherTargetedAttack);
                        break;
                    case "2":
                        System.out.println(noAnotherTargetedAttack);
                        return;
                    default:
                        System.out.println(invalidChoiceMessage);
                        break;
                }
            }
        }
    }

    private int checkValidPlayerIndexInput() {
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        final String targetedAttackPrompt = messages.getString("targetedAttackPrompt");
        final String userPlayedCardAtIndex = messages.getString("userPlayedCardAtIndex");
        final String playerChooseDifferent = messages.getString("playerChooseDifferent");
        final String invalidIndex = messages.getString("invalidIndex");
        final String invalidNumber = messages.getString("invalidNumber");

        while (true) {
            System.out.println(targetedAttackPrompt);
            String userInputTwo = scanner.nextLine();
            try {
                int userIndex = Integer.parseInt(userInputTwo);
                if (game.checkUserWithinBounds(userIndex)) {
                    if (game.checkIfPlayerIsAlive(userIndex)) {
                        final String formattedMessage = MessageFormat.format
                                (userPlayedCardAtIndex, userIndex);
                        System.out.println(formattedMessage);
                        return userIndex;
                    } else {
                        System.out.println(playerChooseDifferent);
                    }
                } else {
                    final String formattedMessage = MessageFormat.format
                            (invalidIndex, game.getNumberOfPlayers() - 1);
                    System.out.println(formattedMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println(invalidNumber);
            }
        }
    }
} 