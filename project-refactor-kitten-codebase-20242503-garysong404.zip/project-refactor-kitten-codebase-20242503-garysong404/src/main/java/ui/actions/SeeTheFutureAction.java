package ui.actions;

import domain.game.Card;
import domain.game.CardType;
import domain.game.Game;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public class SeeTheFutureAction implements Action {
    private final Game game;
    private final ResourceBundle messages;

    public SeeTheFutureAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String seeFutureMessage = messages.getString("seeFutureMessage");
        System.out.println(seeFutureMessage);

        int deckSize = game.getDeckSize();
        final int cardsToSee = 3;
        int cardsToShow = Math.min(cardsToSee, deckSize);

        final String futureCardsMessage =
                MessageFormat.format(messages.getString("futureCardsMessage"), cardsToShow);
        System.out.println(futureCardsMessage);

        for (int i = 0; i < cardsToShow; i++) {
            Card card = game.getCardAtIndex(deckSize - 1 - i);
            final String cardDisplayMessage =
                    MessageFormat.format(messages.getString("cardDisplayFormat"), i + 1,
                            getLocalizedCardType(card.getCardType()));
            System.out.println(cardDisplayMessage);
        }
    }

    private String getLocalizedCardType(CardType cardType) {
        return messages.getString(cardType.name());
    }
} 