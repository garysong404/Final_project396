package ui.actions;

import domain.game.Game;

import java.util.ResourceBundle;

public class DrawFromBottomAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public DrawFromBottomAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        System.out.println(messages.getString("drawFromBottomMessage"));

        game.addCardToHand(game.drawFromBottom());
    }
} 