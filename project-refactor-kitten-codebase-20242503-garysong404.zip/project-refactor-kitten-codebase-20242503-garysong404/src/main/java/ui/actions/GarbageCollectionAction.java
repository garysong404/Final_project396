package ui.actions;

import domain.game.CardType;
import domain.game.Game;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class GarbageCollectionAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public GarbageCollectionAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String garbageMessage = messages.getString("garbageMessage");
        final String enterCardToDiscard = messages.getString("enterCardToDiscard");
        final String invalidCard = messages.getString("invalidCard");
        final String cardDiscarded = messages.getString("cardDiscarded");
        final String cardNotOwned = messages.getString("cardNotOwned");

        System.out.println(garbageMessage);

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        while (true) {
            System.out.println(enterCardToDiscard);
            String cardName = scanner.nextLine().toUpperCase().replace(" ", "_");
            try {
                CardType cardToDiscard = CardType.valueOf(cardName);
                if (game.checkIfPlayerHasCard(game.getPlayerTurn(), cardToDiscard)) {
                    game.playGarbageCollection(cardToDiscard);
                    System.out.println(MessageFormat.format(cardDiscarded, cardToDiscard));
                    break;
                } else {
                    System.out.println(cardNotOwned);
                }
            } catch (IllegalArgumentException e) {
                System.out.println(invalidCard);
            }
        }
    }
} 