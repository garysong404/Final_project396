package ui.actions;

import domain.game.CardType;
import domain.game.Game;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class TwoCardComboAction implements Action {

    private final Game game;
    private final ResourceBundle messages;
    private final CardType cardType;

    public TwoCardComboAction(Game game, ResourceBundle messages, CardType cardType) {
        this.game = game;
        this.messages = messages;
        this.cardType = cardType;
    }

    @Override
    public void execute() {
        if (game.countCards(game.getPlayerTurn(), cardType) >= 2) {
            final String decidedTwoCards = messages.getString("decidedTwoCards");
            final String enterPlayerToSteal = messages.getString("enterPlayerToSteal");
            final String invalidPlayerIndex = messages.getString("invalidPlayerIndex");
            final String playerIsDead = messages.getString("playerIsDead");
            final String cannotStealFromSelf = messages.getString("cannotStealFromSelf");
            final String enterValidInteger = messages.getString("enterValidInteger");
            final String playerStoleCard = messages.getString("playerStoleCard");

            System.out.println(decidedTwoCards);
            game.removeCardFromHand(game.getPlayerTurn(), cardType);
            game.removeCardFromHand(game.getPlayerTurn(), cardType);

            Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
            int playerToStealFrom;
            while (true) {
                System.out.print(enterPlayerToSteal);
                try {
                    playerToStealFrom = scanner.nextInt();
                    if (game.checkUserWithinBounds(playerToStealFrom)) {
                        if (game.checkIfPlayerIsAlive(playerToStealFrom)) {
                            if (playerToStealFrom != game.getPlayerTurn()) {
                                break;
                            } else {
                                System.out.println(cannotStealFromSelf);
                            }
                        } else {
                            System.out.println(playerIsDead);
                        }
                    } else {
                        System.out.println(invalidPlayerIndex);
                    }
                } catch (Exception e) {
                    System.out.println(enterValidInteger);
                    scanner.next();
                }
            }

            CardType stolenCard = game.stealRandomCard(playerToStealFrom).getCardType();
            System.out.println(MessageFormat.format(playerStoleCard, playerToStealFrom, stolenCard));
        } else {
            System.out.println(messages.getString("notEnoughCards"));
        }
    }
} 