package ui.actions;

import domain.game.Game;

import java.util.ResourceBundle;

public class ShuffleAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public ShuffleAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String shuffleMessage = messages.getString("shuffleMessage");
        final String shuffleSuccess = messages.getString("shuffleSuccess");

        System.out.println(shuffleMessage);
        
        final int numberOfShuffles = 1;
        game.playShuffle(numberOfShuffles);
        System.out.println(shuffleSuccess);
    }
} 