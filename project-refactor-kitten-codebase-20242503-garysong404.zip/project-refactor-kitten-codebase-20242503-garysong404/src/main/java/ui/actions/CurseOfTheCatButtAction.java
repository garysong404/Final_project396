package ui.actions;

import domain.game.Game;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.ResourceBundle;
import java.util.Scanner;

public class CurseOfTheCatButtAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public CurseOfTheCatButtAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String curseMessage = messages.getString("curseMessage");
        final String selectPlayerToCurse = messages.getString("selectPlayerToCurse");
        final String playerCursed = messages.getString("playerCursed");
        final String invalidPlayer = messages.getString("invalidPlayer");
        final String cannotCurseSelf = messages.getString("cannotCurseSelf");

        System.out.println(curseMessage);

        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        while (true) {
            System.out.println(selectPlayerToCurse);
            int target = scanner.nextInt();
            if (target == game.getPlayerTurn()) {
                System.out.println(cannotCurseSelf);
            } else if (game.checkUserWithinBounds(target)) {
                game.setPlayerCursed(target, true);
                System.out.println(MessageFormat.format(playerCursed, target));
                break;
            } else {
                System.out.println(invalidPlayer);
            }
        }
    }
} 