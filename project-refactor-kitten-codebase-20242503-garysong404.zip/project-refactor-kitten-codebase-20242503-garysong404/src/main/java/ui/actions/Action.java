package ui.actions;

public interface Action {
    void execute();
} 