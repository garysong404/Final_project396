package ui.actions;

import domain.game.Game;

import java.util.ResourceBundle;

public class SwapTopAndBottomAction implements Action {

    private final Game game;
    private final ResourceBundle messages;

    public SwapTopAndBottomAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        System.out.println(messages.getString("swapTopAndBottomMessage"));

        game.swapTopAndBottom();
    }
} 