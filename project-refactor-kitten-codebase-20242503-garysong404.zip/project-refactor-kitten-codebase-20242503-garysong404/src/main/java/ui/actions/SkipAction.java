package ui.actions;

import domain.game.Game;

import java.text.MessageFormat;
import java.util.ResourceBundle;

public class SkipAction implements Action {
    private final Game game;
    private final ResourceBundle messages;

    public SkipAction(Game game, ResourceBundle messages) {
        this.game = game;
        this.messages = messages;
    }

    @Override
    public void execute() {
        final String decidedSkip = messages.getString("decidedSkip");
        System.out.println(decidedSkip);

        int turnsLeft = game.playSkip(false);
        final String turnsRemainingTemplate = messages.getString("turnsRemaining");
        final String formattedTurnsRemaining = MessageFormat.format(turnsRemainingTemplate, turnsLeft);
        System.out.println(formattedTurnsRemaining);
    }
} 