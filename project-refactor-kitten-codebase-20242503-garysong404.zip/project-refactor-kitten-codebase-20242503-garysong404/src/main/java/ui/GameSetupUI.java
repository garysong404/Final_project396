package ui;

import domain.game.Game;
import domain.game.GameType;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

public class GameSetupUI {

    private final Game game;
    private ResourceBundle messages;

    public GameSetupUI(Game game) {
        this.game = game;
        // Default to English, can be changed by chooseLanguage
        this.messages = ResourceBundle.getBundle("message", new Locale("en"));
    }

    public ResourceBundle chooseLanguage() {
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        final String language = "1. English\n2. 한국어\n";
        final String askLanguage = "Enter the number to choose the language:";
        final String invalidChoice = "Invalid choice. Please enter 1 or 2.";
        System.out.println(language);
        System.out.println(askLanguage);

        while (true) {
            String userInput = scanner.nextLine();
            switch (userInput) {
                case "1":
                    messages = ResourceBundle.getBundle("message", new Locale("en"));
                    System.out.println(messages.getString("setLanguage"));
                    return messages;
                case "2":
                    messages = ResourceBundle.getBundle("message", new Locale("ko"));
                    System.out.println(messages.getString("setLanguage"));
                    return messages;
                default:
                    System.out.println(invalidChoice);
            }
        }
    }

    public void chooseGame() {
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        final String gameModePrompt = messages.getString("gameModePrompt");
        final String gameModeExplodingOption = messages.getString("gameModeExplodingOption");
        final String gameModeImplodingOption = messages.getString("gameModeImplodingOption");
        final String gameModeStreakingOption = messages.getString("gameModeStreakingOption");
        final String gameModeChoicePrompt = messages.getString("gameModeChoicePrompt");
        final String gameModeInvalid = messages.getString("gameModeInvalid");

        System.out.println(gameModePrompt);
        System.out.println(gameModeExplodingOption);
        System.out.println(gameModeImplodingOption);
        System.out.println(gameModeStreakingOption);

        while (true) {
            System.out.print(gameModeChoicePrompt);
            String userInput = scanner.nextLine();
            switch (userInput) {
                case "1":
                    game.retrieveGameMode(GameType.EXPLODING_KITTENS);
                    System.out.println(messages.getString("gameModeExploding"));
                    return;
                case "2":
                    game.retrieveGameMode(GameType.IMPLODING_KITTENS);
                    System.out.println(messages.getString("gameModeImploding"));
                    return;
                case "3":
                    game.retrieveGameMode(GameType.STREAKING_KITTENS);
                    System.out.println(messages.getString("gameModeStreaking"));
                    return;
                default:
                    System.out.println(gameModeInvalid);
            }
        }
    }

    public void chooseNumberOfPlayers() {
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        final String numOfPlayersPrompt = messages.getString("numOfPlayersPrompt");
        final String numOfPlayersTwo = messages.getString("numOfPlayersTwo");
        final String numOfPlayersThree = messages.getString("numOfPlayersThree");
        final String numOfPlayersFour = messages.getString("numOfPlayersFour");
        final String invalidPlayersNum = messages.getString("invalidPlayersNum");

        System.out.println(numOfPlayersPrompt);

        while (true) {
            String userInput = scanner.nextLine();
            final int twoPlayers = 2;
            final int threePlayers = 3;
            final int fourPlayers = 4;
            switch (userInput) {
                case "2":
                    game.setNumberOfPlayers(twoPlayers);
                    System.out.println(numOfPlayersTwo);
                    return;
                case "3":
                    game.setNumberOfPlayers(threePlayers);
                    System.out.println(numOfPlayersThree);
                    return;
                case "4":
                    game.setNumberOfPlayers(fourPlayers);
                    System.out.println(numOfPlayersFour);
                    return;
                default:
                    System.out.println(invalidPlayersNum);
            }
        }
    }
} 