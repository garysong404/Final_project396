package ui;

import domain.game.*;

import java.util.ArrayList;
import java.util.Random;

public class Main {
	public static void main(String[] args) {

		Instantiator instantiator = new Instantiator();
		final int maxDeckSize = 100; // A temporary, larger size to prevent crash
		Deck deck = new Deck(new ArrayList<>(), new Random(), GameType.NONE,
				0, maxDeckSize, instantiator);
		Game game = new Game(0, GameType.NONE, deck, instantiator, new Random());

		GameUI gameUI = new GameUI(game);
		GameController gameController = new GameController(game, gameUI);

		gameController.run();
	}
}
