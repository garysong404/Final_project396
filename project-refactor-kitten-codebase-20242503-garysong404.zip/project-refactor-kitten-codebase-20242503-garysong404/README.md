# Project: Exploding Kitten

## Contributors
Dr. Yiji Zhang

## Dependencies
- JDK 11
- JUnit 5.10
- Gradle 8.10

## Fair Use Clause
The codebase is strictly used for educational purposes only.
The codebase shall not be made public or distributed outside the course.

The original codebase is obtained from a past student's
project in Dr. Yiji Zhang's class at Northwestern University.
The names of the authors are removed on purpose to
not reveal their identities.
The codebased is maintained by Dr. Yiji Zhang.

