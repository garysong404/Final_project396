rootProject.name = "course-project"

